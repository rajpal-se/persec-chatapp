-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Jan 21, 2023 at 12:05 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int NOT NULL,
  `sender` int NOT NULL,
  `receiver` int NOT NULL,
  `message` text NOT NULL,
  `seen` tinyint(1) NOT NULL,
  `time` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receiver`, `message`, `seen`, `time`) VALUES
(1, 4, 3, 'Hi jennifer', 1, 1674285885862),
(2, 3, 4, 'Hi Megan', 1, 1674285933032),
(3, 4, 3, 'This Saturday there is my birthday party.', 1, 1674286139383),
(4, 4, 3, 'I like you to join us', 1, 1674286151719),
(5, 3, 4, 'Party, It\'s great.', 1, 1674286222540),
(6, 3, 4, 'But I am busy for last few weeks for upcoming movie promotion.', 1, 1674286308010),
(7, 4, 3, 'Ok, but party is at night.', 1, 1674286360720),
(8, 3, 4, 'yeah that\'s good.', 1, 1674286399630),
(9, 3, 4, 'I\'ll come.', 1, 1674286465675),
(10, 4, 3, 'Thanks', 1, 1674286477169),
(11, 3, 4, 'By the way where the party?', 1, 1674286513117),
(12, 4, 3, 'I will share the location very soon.', 1, 1674286545488),
(13, 3, 4, 'ok', 1, 1674286551058),
(14, 4, 3, 'Bye, I also have to invite others.', 1, 1674286584209),
(15, 4, 3, 'See you in party :)', 1, 1674286600989),
(16, 3, 4, 'Bye!', 1, 1674286629500),
(17, 4, 1, 'Hi Kenau', 1, 1674286871695),
(18, 1, 4, 'Hi Megan', 1, 1674286889408),
(19, 1, 4, 'How are you?', 1, 1674286897529),
(20, 4, 1, 'I\'m good', 1, 1674286920160),
(21, 1, 4, 'great', 1, 1674286937743),
(22, 4, 1, 'I am having birthday party this Saturday', 1, 1674286979082),
(23, 4, 1, 'I would like you to be there.', 1, 1674287013036),
(24, 1, 4, 'Ya, of course', 1, 1674287062250),
(25, 4, 1, 'that\'s great.', 1, 1674287084702),
(26, 4, 1, 'I\'ll share you the party location very soon', 1, 1674287117191),
(27, 1, 4, 'ok', 1, 1674287119927),
(28, 4, 1, 'See you in party, Bye!', 1, 1674287150261),
(29, 1, 4, 'See you in party.', 1, 1674287162136),
(30, 4, 2, 'Hi brad', 1, 1674287214437),
(31, 2, 4, 'Hi Megan', 1, 1674287221887),
(32, 4, 2, 'I hope, this Saturday you will be free at night.', 1, 1674287307298),
(33, 2, 4, 'Yes, I am.', 1, 1674287317860),
(34, 2, 4, 'but why?', 1, 1674287323653),
(35, 4, 2, 'It\'s my birthday.', 1, 1674287346458),
(36, 4, 2, 'I am giving party.', 1, 1674287416599),
(37, 2, 4, 'wow, It will be fun.', 1, 1674287432897),
(38, 4, 2, 'ya, I need you to us.', 1, 1674287456714),
(39, 2, 4, 'Sure, Where it is?', 1, 1674287476252),
(40, 4, 2, 'Nearby my home', 1, 1674287498064),
(41, 4, 2, 'I\'ll share the exact location very soon.', 1, 1674287539344),
(42, 2, 4, 'ok', 1, 1674287570216),
(43, 4, 2, 'Bye', 1, 1674287666241),
(44, 2, 4, 'Bye, See you in party', 1, 1674287698548);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` text NOT NULL,
  `gender` varchar(6) NOT NULL,
  `image` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `last_active` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `pass`, `gender`, `image`, `active`, `last_active`) VALUES
(1, 'Kenau', 'Reeves', 'kenaureeves@gmail.com', 'a5137cef1cbc1f08b8deb0e9a16b7497', 'male', '/images/uploads/f667ba6d0e15c0b40a54ad21f73006de.jpeg', 0, 1674287171991),
(2, 'Brad', 'Pitt', 'bradpitt@gmail.com', 'a5137cef1cbc1f08b8deb0e9a16b7497', 'male', '/images/uploads/05acdeb774e49287065f35c6bd43869f.png', 0, 1674287780663),
(3, 'Jennifer', 'Connelly', 'jenniferconnelly@gmail.com', 'a5137cef1cbc1f08b8deb0e9a16b7497', 'female', '/images/uploads/8d1a7ad0b079e1cb2555e96d6885da62.jpeg', 0, 1674286676760),
(4, 'Megan', 'Fox', 'meganfox@gmail.com', 'a5137cef1cbc1f08b8deb0e9a16b7497', 'female', '/images/uploads/2abae52f7f1073309eb9df60b0a250f7.jpeg', 1, 1674302713418);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
